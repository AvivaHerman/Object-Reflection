package IBM_assignment;

public class Address {
	public Street st;
	public String phone;
}
