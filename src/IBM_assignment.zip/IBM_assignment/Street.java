package IBM_assignment;

public class Street {
	public String name;
	public int num;
}
