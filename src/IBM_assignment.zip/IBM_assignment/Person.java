package IBM_assignment;

public class Person {
	public int age; 
    public Name name;
    public Address address;
}
