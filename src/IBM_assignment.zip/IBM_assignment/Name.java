package IBM_assignment;

public class Name {
    public String firstName;
    public String lastName;  
}
