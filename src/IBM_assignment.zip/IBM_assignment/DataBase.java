package IBM_assignment;

import java.util.LinkedList;

public class DataBase {
	public int num;
	public Person[] names;
	public LinkedList<Name> ids;
}
